/**
 * A simple activity that logs a message
 */
export declare function sayHello(name: string): Promise<string>;
