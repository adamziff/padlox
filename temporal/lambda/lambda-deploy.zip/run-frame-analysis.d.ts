/**
 * Script to run the frame analysis workflow for testing
 */
export {};
