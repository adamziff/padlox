/**
 * Simple script to run the workflow for testing
 */
export {};
