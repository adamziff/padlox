import { Worker } from '@temporalio/worker';
export declare function createWorker(): Promise<Worker>;
