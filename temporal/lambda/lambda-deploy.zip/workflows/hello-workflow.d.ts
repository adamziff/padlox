/**
 * A simple workflow that calls the sayHello activity
 */
export declare function helloVideoWorkflow(name: string): Promise<string>;
